export enum STAGES {
  DEV = "development",
  PROD = "production",
}
