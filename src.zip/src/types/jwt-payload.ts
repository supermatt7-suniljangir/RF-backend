export interface JwtPayload {
    _id: string;
    role?: string;
  }