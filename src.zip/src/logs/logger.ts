import winston from "winston";
import { NODE_ENV } from "../config/configURLs";
import fs from "fs";
import path from "path";

// Ensure logs directory exists
const logDir = path.join(__dirname, "logs");
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir);
}

// Custom log format
const logFormat = winston.format.combine(
  winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
  winston.format.errors({ stack: true }),
  winston.format.splat(),
  winston.format.printf(({ timestamp, level, message, ...rest }) => {
    // Handle the second argument if present
    const splat = rest[Symbol.for('splat')];
    const secondArg = Array.isArray(splat) ? 
      JSON.stringify(splat[0], null, 2) : '';
    
    return `${timestamp} ${level}: ${message}${secondArg ? ' ' + secondArg : ''}`;
  })
);

// Create logger
const logger = winston.createLogger({
  level: NODE_ENV === "production" ? "info" : "debug",
  format: logFormat,
  transports: [
    // Console transport (always active)
    new winston.transports.Console({
      format: winston.format.combine(winston.format.colorize(), logFormat),
    }),

    // File transports
    new winston.transports.File({
      filename: "logs/error.log",
      level: "error",
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    }),
    new winston.transports.File({
      filename: "logs/combined.log",
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    }),
  ],
});

export default logger;